# 実験4: Python Agent SDK (a2ui-agent-sdk 0.11.0, PyPI) — Macros
import json
from a2ui.builder.v1_0 import Action, Button, Card, Column, DynamicString, Text
from a2ui.transformers.macros import macro, MacroExpander
from a2ui.core.basic_catalog import BasicCatalog
from a2ui.processor import A2uiRequestProcessor
from a2ui.parser import A2uiPart, TextPart

FLIGHTS = {"NH105": {"route": "羽田 → ロサンゼルス", "dep": "00:05"}}  # サーバー側DBの代わり

@macro
def FlightCard(flight_id: str, status: DynamicString, on_rebook: Action) -> Card:
    """便のサマリーカード。サーバー側で便情報を引いて組み立てる。

    Args:
        flight_id: 便ID（例 "NH105"）。
        status: 運航ステータス（データバインディング可）。
        on_rebook: 振替ボタン押下時のアクション。
    """
    f = FLIGHTS[flight_id]
    return Card(child=Column(children=[
        Text(text=f"### {flight_id}"),
        Text(text=f"{f['route']}（{f['dep']} 発）", variant="caption"),
        Text(text=status),
        Button(child=Text(text="振替を相談"), action=on_rebook),
    ]))

expander = MacroExpander([FlightCard], on_error="raise")
inference_catalog = expander.transform_to_inference_catalog(BasicCatalog("1.0"))
processor = A2uiRequestProcessor(catalogs=[inference_catalog])
snippet = processor.prompt_snippet
i = snippet.find("FlightCard")
print("## プロンプトに載る FlightCard のシグネチャ\n" + snippet[i-40:i+500])

llm_output = '''遅延が出ています。
<a2ui>
$/flight/status = "45分遅延"
root = FlightCard("NH105", $/flight/status, Event("rebook", {flight: "NH105"}))
</a2ui>'''
wire = []
for part in processor.parse_response(llm_output):
    if isinstance(part, TextPart):
        print("\n[text]", part.text)
    elif isinstance(part, A2uiPart):
        for m in expander.transform_to_transport(part.a2ui):
            wire.append(m.model_dump(by_alias=True, exclude_none=True))
print("\n## 展開後のワイヤーメッセージ\n" + json.dumps(wire, ensure_ascii=False, indent=1))
block = llm_output.split("<a2ui>")[1].split("</a2ui>")[0]
print("\n## LLM出力 vs ワイヤー（文字数）", len(block), len(json.dumps(wire, ensure_ascii=False)))
