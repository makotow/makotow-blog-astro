# 実験5: Python Agent SDK で callAgentFunction に応答する（PyPI 0.11.0）
import asyncio, json
from a2ui.core.catalog import Catalog, AgentFunction
from a2ui.rpc import RendererToAgentMessageProcessor

TAKEN = {"12A", "12B"}
decl = Catalog.from_json(json.load(open("travel_catalog.json")))
travel = decl.copy_with(agent_functions=[
    AgentFunction.from_api(decl.functions["checkSeat"], lambda args: args["seat"].upper() not in TAKEN)
])
proc = RendererToAgentMessageProcessor([travel], on_action=lambda m: print("action:", m) or True)

async def main():
    for seat in ["12A", "14C"]:
        msg = {"version": "1.0", "callAgentFunction": {"surfaceId": "seat", "functionCallId": f"c-{seat}",
               "callFunction": {"@call": "checkSeat", "catalogId": travel.id, "args": {"flight": "NH 105", "seat": seat}}}}
        r = await proc.process_message(msg)
        print(seat, "handled=", r.handled, [x.model_dump(by_alias=True, exclude_none=True) for x in r.replies])
    # 未知の関数
    r = await proc.process_message({"version": "1.0", "callAgentFunction": {"surfaceId": "seat", "functionCallId": "c-x",
        "callFunction": {"@call": "bookSeat", "catalogId": travel.id, "args": {}}}})
    print("unknown:", [x.model_dump(by_alias=True, exclude_none=True) for x in r.replies])
asyncio.run(main())
