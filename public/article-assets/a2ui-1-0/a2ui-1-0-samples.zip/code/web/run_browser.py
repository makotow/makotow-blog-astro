import asyncio, json, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1280, 'height': 820})
        logs = []
        pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}'))
        pg.on('pageerror', lambda e: logs.append(f'[pageerror] {e}'))
        await pg.goto('http://localhost:8765/index.html'); await pg.wait_for_timeout(500)
        print('\n'.join(logs)); logs.clear()
        print('validatePayload:', await pg.evaluate('JSON.stringify(window.validated)'))
        await pg.evaluate('scenario.start()'); await pg.wait_for_timeout(800)
        await pg.screenshot(path='shot1_initial.png')
        inp = pg.locator('input').first
        await inp.fill('12A'); await pg.wait_for_timeout(1200)
        await pg.screenshot(path='shot2_taken.png')
        await inp.fill('14C'); await pg.wait_for_timeout(1200)
        await pg.screenshot(path='shot3_ok.png')
        print('viewport via callRendererFunction:', await pg.evaluate('scenario.viewport().then(JSON.stringify)'))
        print('openUrl via SDK:', await pg.evaluate('scenario.agentOpenUrlViaSdk()'))
        await pg.evaluate('scenario.agentOpenUrlRaw()'); await pg.wait_for_timeout(400)
        await pg.get_by_role('button').first.click(); await pg.wait_for_timeout(600)
        print('lastAction:', await pg.evaluate('JSON.stringify(window.lastAction)'))
        print('lastError:', await pg.evaluate('JSON.stringify(window.lastError)'))
        await pg.screenshot(path='shot4_final.png', full_page=True)
        # accessibility
        btn = await pg.evaluate('''(()=>{const b=[...document.querySelectorAll('*')].filter(e=>e.getAttribute && (e.getAttribute('aria-label')||e.getAttribute('aria-live')||e.getAttribute('aria-description'))).map(e=>({tag:e.tagName.toLowerCase(),role:e.getAttribute('role'),label:e.getAttribute('aria-label'),desc:e.getAttribute('aria-description')||e.getAttribute('aria-describedby'),live:e.getAttribute('aria-live')}));return JSON.stringify(b)})()''')
        print('aria attrs:', btn)
        snap = await pg.locator('#app').aria_snapshot()
        print('aria snapshot:\n' + snap)
        wire = await pg.evaluate('JSON.stringify(window.wire)')
        open('wire_log.json','w').write(json.dumps(json.loads(wire), ensure_ascii=False, indent=1))
        print('wire messages:', len(json.loads(wire)))
        print('\n'.join(logs[:30]))
        await b.close()
asyncio.run(main())
