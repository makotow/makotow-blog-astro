// 実験4: v0.9 流の書き方を 1.0 として送ったら？（エージェント側SDK検証 vs レンダラー）
import { validatePayload, CatalogConfig } from '@a2ui/agent';
const basic = CatalogConfig.fromPath('/home/claude/a2ui-src/catalogs/basic/v1/catalog.json').catalog;
const cases = {
  'v0.9流 path / accessibility': [{ version: '1.0', createSurface: { surfaceId: 's', catalogId: basic.id, components: [
    { id: 'root', component: 'Text', text: { path: '/name' }, accessibility: { label: 'x' } }] } }],
  'version: "v1.0"（v付き）': [{ version: 'v1.0', createSurface: { surfaceId: 's', catalogId: basic.id, components: [{ id: 'root', component: 'Text', text: 'x' }] } }],
  'theme 付き createSurface': [{ version: '1.0', createSurface: { surfaceId: 's', catalogId: basic.id, theme: { primaryColor: '#f00' }, components: [{ id: 'root', component: 'Text', text: 'x' }] } }],
  '1.0 正しい書き方': [{ version: '1.0', createSurface: { surfaceId: 's', catalogId: basic.id, components: [
    { id: 'root', component: 'Text', text: { '@path': '/name' }, '@accessibility': { label: 'x', live: 'polite' } }] } }],
};
for (const [name, msgs] of Object.entries(cases)) {
  try { validatePayload([basic], msgs); console.log(`OK   ${name}`); }
  catch (e) { console.log(`NG   ${name}\n     → ${e.message.split('\n')[0].slice(0, 220)}`); }
}
