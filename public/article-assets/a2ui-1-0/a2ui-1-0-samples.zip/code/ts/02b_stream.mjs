// 実験2b: 文を分けた Express をストリーミングすると、どの単位でメッセージが出るか
import { A2uiGenerator, CatalogConfig } from '@a2ui/agent';
import { MessageProcessor, basicCatalog } from '@a2ui/web_core/v1_0';
const basic = CatalogConfig.fromPath('/home/claude/a2ui-src/catalogs/basic/v1/catalog.json');
const caps = new MessageProcessor([basicCatalog], undefined, { version: '1.0' }).getRendererCapabilities({ version: '1.0' });
const proc = new A2uiGenerator([basic]).createProcessor(caps);
const reply = `候補を表示します。
<a2ui>
root = Column([header, list])
header = Text("東京→大阪 の便", "caption")
$/flights = [{no: "NH 15", dep: "08:00"}, {no: "JL 113", dep: "09:30"}]
list = Column(_template($/flights, row))
row = Text(formatString("\${no} \${dep} 発"))
</a2ui>`;
const stream = proc.openStream();
const t0 = Date.now(); let n = 0;
for (const ch of reply.match(/[\s\S]{1,12}/g)) {
  for (const p of stream.feed(ch)) {
    const kind = p.type === 'text' ? `text ${JSON.stringify(p.text)}` :
      p.a2ui.map(m => { const k = Object.keys(m).find(k => k !== 'version'); const b = m[k]; return `${k}(${(b.components||[]).map(c=>c.id).join(',')}${b.path!==undefined?' path='+b.path:''})`; }).join(' + ');
    console.log(`chunk#${String(n).padStart(2)} ${kind}`);
  }
  n++;
}
for (const p of stream.close()) console.log('close', p.type);
