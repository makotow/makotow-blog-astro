// 実験3: コンポーネント単位のカタログ混在 (@catalogId) と @ エスケープ
import { MessageProcessor, basicCatalog, Catalog } from '@a2ui/web_core/v1_0';
const BADGE = 'https://example.com/a2ui/badge/v1/catalog.json';
const badgeCatalog = Catalog.fromJson({
  $schema: 'https://json-schema.org/draft/2020-12/schema', catalogId: BADGE, protocolVersion: '1.0',
  components: { Badge: { type: 'object', properties: { component: { const: 'Badge' }, label: { $ref: 'common_types.json#/$defs/DynamicString' }, tone: { enum: ['info', 'warn'] } }, required: ['component', 'label'] } },
  functions: {}, $defs: {},
});
const p = new MessageProcessor([basicCatalog, badgeCatalog], undefined, { version: '1.0' });
const errs = p.processMessagesWithErrors({ version: '1.0', createSurface: {
  surfaceId: 'mix', catalogId: basicCatalog.id,
  dataModel: { tier: 'Diamond' },
  components: [
    { id: 'root', component: 'Row', children: ['name', 'badge'] },
    { id: 'name', component: 'Text', text: 'Makoto' },
    { id: 'badge', component: 'Badge', '@catalogId': BADGE, label: { '@path': '/tier' }, tone: 'info' },
  ] } });
console.log('mixed catalogs errors:', errs);
const s = p.getSurface('mix');
for (const id of ['name', 'badge']) { const c = s.componentsModel.get(id); console.log(id, '→', c.type, 'catalog =', c.catalog?.id); }

// @catalogId を付けないと basic カタログで解決され、Badge は未知コンポーネント扱い
const errs2 = p.processMessagesWithErrors({ version: '1.0', createSurface: { surfaceId: 'mix2', catalogId: basicCatalog.id,
  components: [{ id: 'root', component: 'Badge', label: 'x' }] } });
console.log('\nwithout @catalogId:', errs2.map(e => e.error.code + ' ' + e.error.message));

// 1つのサーフェスに 0.9 と 1.0 のカタログは混在できない（カタログの protocolVersion が一致している必要）
// 未知の単一 @ キーは拒否される
const errs3 = p.processMessagesWithErrors({ version: '1.0', updateComponents: { surfaceId: 'mix', components: [
  { id: 'name', component: 'Text', text: 'x', '@foo': 1 } ] } });
console.log('\nunknown @ key:', errs3.map(e => e.error.code + ' ' + e.error.message));
const c2 = p.getSurface('mix2')?.componentsModel.get('root');
console.log('mix2 root:', c2?.type, 'catalog =', c2?.catalog?.id ?? '(unresolved)');
const strict = new MessageProcessor([basicCatalog, badgeCatalog], undefined, { version: '1.0', validationConfig: (await import('@a2ui/web_core/v1_0')).STRICT_VALIDATION });
console.log('STRICT without @catalogId:', strict.processMessagesWithErrors({ version: '1.0', createSurface: { surfaceId: 'mix3', catalogId: basicCatalog.id,
  components: [{ id: 'root', component: 'Badge', label: 'x' }] } }).map(e => e.error.code + ' ' + e.error.message));
