// 実験1: v1.0 のメッセージをレンダラーコア(@a2ui/web_core)で処理する
import { MessageProcessor, basicCatalog, STRICT_VALIDATION, RELAXED_VALIDATION } from '@a2ui/web_core/v1_0';

const CAT = basicCatalog.id;
const log = (t, v) => console.log(`\n### ${t}\n` + (typeof v === 'string' ? v : JSON.stringify(v, null, 2)));
const actions = [];
const p = new MessageProcessor([basicCatalog], (a) => actions.push(a), { version: '1.0', validationConfig: STRICT_VALIDATION });

// (1) createSurface 1通で components + dataModel + metadata を同時送信
p.processMessages({
  version: '1.0',
  createSurface: {
    surfaceId: 'booking',
    catalogId: CAT,
    sendDataModel: true,
    metadata: { extensions: { exampleTrace: { traceId: 'abc-123' } } },
    dataModel: { guest: { name: 'Makoto' }, seats: 2 },
    components: [
      { id: 'root', component: 'Column', children: ['title', 'name', 'submit'] },
      { id: 'title', component: 'Text', text: { '@call': 'formatString', args: { value: 'ようこそ ${/guest/name} さん（${/seats}名）' } },
        '@accessibility': { live: 'polite' } },
      { id: 'name', component: 'TextField', label: 'お名前', value: { '@path': '/guest/name' },
        '@checks': [{ condition: { '@call': 'required', args: { value: { '@path': '/guest/name' } } }, message: '必須です' }] },
      { id: 'submit_label', component: 'Text', text: '送信' },
      { id: 'submit', component: 'Button', child: 'submit_label',
        '@accessibility': { label: '予約フォームを送信', description: '入力内容で予約を確定します' },
        '@metadata': { extensions: { exampleAnalytics: { event: 'cta_click' } } },
        action: { event: { name: 'submit', context: { name: { '@path': '/guest/name' } } } } },
    ],
  },
});
const s = p.getSurface('booking');
log('surface created', { id: s.id, catalog: s.catalog.id, components: [...s.componentsModel.keys], protocolVersion: s.protocolVersion });
log('dataModel (applied before components)', s.dataModel.get('/'));
log('surface metadata', s.metadata);
const btn = s.componentsModel.get('submit');
log('button component model', { type: btn.type, properties: btn.properties, metadata: btn.metadata });

// (2) updateDataModel: value=null で削除
p.processMessages({ version: '1.0', updateDataModel: { surfaceId: 'booking', path: '/seats', value: null } });
log('after delete /seats', s.dataModel.get('/'));

// (3) 送信データモデル(sendDataModel=true → トランスポートmetadataに添付)
log('getRendererDataModel(1.0)', p.getRendererDataModel('1.0'));

// (4) theme を付けた createSurface は STRICT で不正
const errs = p.processMessagesWithErrors({ version: '1.0', createSurface: { surfaceId: 'themed', catalogId: CAT, theme: { primaryColor: '#f00' } } });
log('STRICT: createSurface with theme', errs);
const p2 = new MessageProcessor([basicCatalog], undefined, { version: '1.0', validationConfig: RELAXED_VALIDATION });
const errs2 = p2.processMessagesWithErrors({ version: '1.0', createSurface: { surfaceId: 'themed', catalogId: CAT, theme: { primaryColor: '#f00' } } });
log('RELAXED: createSurface with theme', { errors: errs2, created: !!p2.getSurface('themed'), theme: p2.getSurface('themed')?.theme });

// (5) v0.9 風の書き方 (prefixなし accessibility / path) を 1.0 で送るとどうなるか
const errs3 = p.processMessagesWithErrors({ version: '1.0', updateComponents: { surfaceId: 'booking', components: [
  { id: 'title', component: 'Text', text: { path: '/guest/name' }, accessibility: { label: 'x' } } ] } });
log('v0.9-style keys sent as 1.0', errs3);

// (6) renderer capabilities
log('renderer capabilities', p.getRendererCapabilities({ version: '1.0' }));
