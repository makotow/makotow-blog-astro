// 実験2: Agent SDK (@a2ui/agent) — Express 推論フォーマット / プロンプト生成 / ストリーミング
import { A2uiGenerator, CatalogConfig, DirectJsonFormatFactory, ExpressFormatFactory } from '@a2ui/agent';
import { MessageProcessor, basicCatalog } from '@a2ui/web_core/v1_0';

const SRC = '/home/claude/a2ui-src';
const basic = CatalogConfig.fromPath(`${SRC}/catalogs/basic/v1/catalog.json`);
const renderer = new MessageProcessor([basicCatalog], undefined, { version: '1.0' });
const caps = renderer.getRendererCapabilities({ version: '1.0' }); // レンダラーが申告する能力

const gen = new A2uiGenerator([basic]);
const express = gen.createProcessor(caps);                                   // 既定 = Express
const direct  = gen.createProcessor(caps, new DirectJsonFormatFactory());

console.log('## promptSnippet の長さ（文字数）');
console.log({ express: express.promptSnippet.length, directJson: direct.promptSnippet.length });

// LLM の出力を模した応答（このサンドボックスにはLLM APIキーが無いため手書き）
const llmReply = `明日の便の情報です。
<a2ui>
$/flight/number = "NH 105"
$/flight/gate = "B12"
$/flight/fare = 48200
root = Card(
  Column([
    Text($/flight/number),
    Text(formatString("搭乗口 \${/flight/gate}"), "caption"),
    Text(formatCurrency($/flight/fare, "JPY")),
    Button(Text("チェックイン"), action=Event("check_in", {flight: $/flight/number}))
  ])
)
</a2ui>
ほかに確認したいことはありますか？`;

const parts = express.parseResponse(llmReply);
for (const p of parts) {
  if (p.type === 'text') console.log('\n[text]', JSON.stringify(p.text));
  else {
    console.log('\n[a2ui]', JSON.stringify(p.a2ui, null, 1));
    renderer.processMessages(p.a2ui);
  }
}
const block = llmReply.match(/<a2ui>([\s\S]*)<\/a2ui>/)[1];
const wire = JSON.stringify(parts.find(p => p.type !== 'text').a2ui);
console.log('\n## Express ブロック vs ワイヤーJSON（文字数）', { express: block.length, wireJson: wire.length, ratio: (wire.length / block.length).toFixed(2) });
console.log('## レンダラー側に生成されたサーフェス', [...renderer.getSurfaces().keys()], renderer.getSurface('main')?.dataModel.get('/'));

// ストリーミング: 15文字ずつ流し込み、どの時点で何が出るか
console.log('\n## ストリーミング (15文字チャンク)');
const stream = express.openStream();
let i = 0;
for (let off = 0; off < llmReply.length; off += 15) {
  const out = stream.feed(llmReply.slice(off, off + 15));
  for (const p of out) console.log(`chunk#${i}:`, p.type === 'text' ? `text ${JSON.stringify(p.text)}` : `a2ui ${p.a2ui.map(m => Object.keys(m).find(k => k !== 'version')).join(',')}`);
  i++;
}
for (const p of stream.close()) console.log('close:', p.type);

// 壊れた出力（未知のコンポーネント）を与えたとき
try {
  express.parseResponse('<a2ui>root = Carousel([Text("x")])</a2ui>');
} catch (e) { console.log('\n## 未知コンポーネント →', e.constructor.name, e.message.slice(0, 160)); }

// v1.0 の basic カタログでは Text の見出し variant (h1〜h5) が無くなった
try { express.parseResponse('<a2ui>root = Text("見出し", "h3")</a2ui>'); }
catch (e) { console.log('\n## Text variant "h3" →', e.detail); }
